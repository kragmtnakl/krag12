import os
from flask import Flask, request, jsonify
from time import time

app = Flask(__name__)

clicks = {}

@app.route('/click', methods=['POST'])
def click():
    ip = request.remote_addr
    now = time()

    if ip in clicks:
        if now - clicks[ip] < 3:
            return jsonify({"error": "Too many clicks, possible fraud."}), 429

    clicks[ip] = now
    return jsonify({"message": "Click registered successfully."}), 200

if __name__ == '__main__':
    port = int(os.environ.get("PORT", 5000))
    app.run(host='0.0.0.0', port=port)
